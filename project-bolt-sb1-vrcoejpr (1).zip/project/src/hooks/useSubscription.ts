import { useState, useEffect, useCallback } from "react";
import { supabase } from "../lib/supabase";

export interface SubscriptionState {
  isPremium: boolean;
  plan: string | null;
  expiresAt: string | null;
  loading: boolean;
  error: string | null;
}

const RAZORPAY_FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/razorpay-checkout`;

export function useSubscription() {
  const [state, setState] = useState<SubscriptionState>({
    isPremium: false,
    plan: null,
    expiresAt: null,
    loading: true,
    error: null,
  });

  const checkStatus = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setState({ isPremium: false, plan: null, expiresAt: null, loading: false, error: null });
        return;
      }

      const res = await fetch(RAZORPAY_FUNCTION_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: "check_status" }),
      });

      if (!res.ok) {
        setState({ isPremium: false, plan: null, expiresAt: null, loading: false, error: null });
        return;
      }
      const data = await res.json();

      setState({
        isPremium: data.is_premium || false,
        plan: data.plan || null,
        expiresAt: data.expires_at || null,
        loading: false,
        error: null,
      });
    } catch (err) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error: err instanceof Error ? err.message : "Failed to check subscription",
      }));
    }
  }, []);

  useEffect(() => {
    checkStatus();
  }, [checkStatus]);

  const createOrder = useCallback(async (plan: "semi_annual" | "annual"): Promise<{
    orderId: string | null;
    amount: number | null;
    keyId: string | null;
    planName: string | null;
    displayPrice: string | null;
    demoMode: boolean;
    error: string | null;
  }> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return { orderId: null, amount: null, keyId: null, planName: null, displayPrice: null, demoMode: false, error: "Not signed in" };

      const res = await fetch(RAZORPAY_FUNCTION_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: "create_order", plan }),
      });

      if (!res.ok) throw new Error(`Failed: ${res.status}`);
      const data = await res.json();

      if (data.demo_mode) {
        return { orderId: null, amount: null, keyId: null, planName: null, displayPrice: null, demoMode: true, error: null };
      }

      return {
        orderId: data.order_id,
        amount: data.amount,
        keyId: data.key_id,
        planName: data.plan_name,
        displayPrice: data.display_price,
        demoMode: false,
        error: null,
      };
    } catch (err) {
      return { orderId: null, amount: null, keyId: null, planName: null, displayPrice: null, demoMode: false, error: err instanceof Error ? err.message : "Failed" };
    }
  }, []);

  const verifyPayment = useCallback(async (
    razorpayPaymentId: string,
    razorpayOrderId: string,
    razorpaySignature: string,
  ): Promise<boolean> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return false;

      const res = await fetch(RAZORPAY_FUNCTION_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          action: "verify_payment",
          razorpay_payment_id: razorpayPaymentId,
          razorpay_order_id: razorpayOrderId,
          razorpay_signature: razorpaySignature,
        }),
      });

      if (!res.ok) return false;
      const data = await res.json();

      if (data.success) {
        await checkStatus();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, [checkStatus]);

  return { ...state, checkStatus, createOrder, verifyPayment };
}
