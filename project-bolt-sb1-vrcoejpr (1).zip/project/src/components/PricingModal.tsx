import { X, Crown, Check, Lock } from "lucide-react";

interface PricingModalProps {
  onClose: () => void;
  isPremium: boolean;
  expiresAt: string | null;
}

const PLANS = [
  {
    id: "semi_annual",
    name: "6 Months",
    price: "₹415",
    period: "per 6 months",
    features: ["50 image generations/day", "Priority AI responses", "No ads", "Unlimited chat"],
    best: false,
  },
  {
    id: "annual",
    name: "1 Year",
    price: "₹830",
    period: "per year • save 33%",
    features: ["50 image generations/day", "Priority AI responses", "No ads", "Unlimited chat", "Save ₹165"],
    best: true,
  },
];

export default function PricingModal({ onClose, isPremium, expiresAt }: PricingModalProps) {
  const fmtDate = (d: string) =>
    new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1a1f] border border-white/10 rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl animate-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative p-6 text-center border-b border-white/8">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            <X size={14} className="text-gray-400" />
          </button>
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/20">
            <Crown size={24} className="text-white" />
          </div>
          <h2 className="text-lg font-bold text-white">JK Bot Premium</h2>
          <p className="text-xs text-gray-400 mt-1">Unlock the full power of AI</p>
        </div>

        {isPremium ? (
          <div className="p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
              <Crown size={22} className="text-amber-400" />
            </div>
            <p className="text-sm font-semibold text-white mb-1">You're already Premium!</p>
            <p className="text-xs text-gray-500">
              Active{expiresAt ? ` until ${fmtDate(expiresAt)}` : ""}.
            </p>
            <button
              onClick={onClose}
              className="mt-5 w-full py-2.5 rounded-xl bg-white/8 hover:bg-white/12 text-gray-300 text-sm font-medium transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="p-5 space-y-3">
            {PLANS.map((plan) => (
              <div
                key={plan.id}
                className={`rounded-xl p-4 border relative ${
                  plan.best
                    ? "border-blue-500/40 bg-blue-500/5"
                    : "border-white/8 bg-white/3"
                }`}
              >
                {plan.best && (
                  <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                    BEST VALUE
                  </span>
                )}
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-white">{plan.name}</p>
                  <div className="text-right">
                    <span className="text-xl font-bold text-white">{plan.price}</span>
                    <span className="text-[10px] text-gray-500 block">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-1 mb-3">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-1.5 text-xs text-gray-400">
                      <Check size={11} className="text-emerald-400 flex-shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
                {/* Payments closed — no payment button */}
                <div className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 border border-white/8">
                  <Lock size={13} className="text-gray-500" />
                  <span className="text-xs text-gray-500 font-medium">Payments currently closed</span>
                </div>
              </div>
            ))}

            <p className="text-center text-[11px] text-gray-600 pt-1">
              Payment integration coming soon. Contact <span className="text-gray-400">Mumtaz Ali</span> for updates.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
