import { useState } from "react";
import {
  Sparkles, MoreVertical, MessageCircle, Image as ImageIcon,
  Bell, BookOpen, LogOut, Crown, Lock, X, ChevronRight,
  Clock, Trash2, MessageSquare, Settings,
} from "lucide-react";
import { useAuth } from "./hooks/useAuth";
import { useSubscription } from "./hooks/useSubscription";
import { supabase } from "./lib/supabase";
import AuthScreen from "./components/AuthScreen";
import ChatPanel from "./components/ChatPanel";
import RemindersPanel from "./components/RemindersPanel";
import NotesPanel from "./components/NotesPanel";
import ImageGenPanel from "./components/ImageGenPanel";
import PricingModal from "./components/PricingModal";

type Tab = "chat" | "reminders" | "notes" | "imagegen";

/* ─── Mini history list (used inside profile sheet) ────── */
function HistoryList({ onClearAll }: { onClearAll: () => void }) {
  const [sessions, setSessions] = useState<
    { date: string; preview: string; count: number }[]
  >([]);
  const [loaded, setLoaded] = useState(false);
  const [busy,   setBusy]   = useState(false);

  async function load() {
    if (loaded) return;
    setBusy(true);
    const { data } = await supabase
      .from("chat_messages")
      .select("content, role, created_at")
      .order("created_at", { ascending: false })
      .limit(300);

    if (data) {
      const byDate: Record<string, { preview: string; count: number }> = {};
      for (const msg of data) {
        const day = new Date(msg.created_at).toLocaleDateString("en-IN", {
          day: "numeric", month: "short", year: "numeric",
        });
        if (!byDate[day]) byDate[day] = { preview: msg.content?.slice(0, 70) || "", count: 0 };
        byDate[day].count++;
      }
      setSessions(Object.entries(byDate).map(([date, v]) => ({ date, ...v })));
    }
    setBusy(false);
    setLoaded(true);
  }

  return (
    <div className="mt-1">
      {/* Accordion toggle */}
      <button
        onClick={load}
        className="flex items-center justify-between w-full px-4 py-3 rounded-2xl bg-white/4 border border-white/8 hover:bg-white/7 transition-all text-sm"
      >
        <span className="flex items-center gap-2 text-gray-300 font-medium">
          <Clock size={14} className="text-cyan-400" /> Chat History
        </span>
        <ChevronRight size={13} className={`text-gray-600 transition-transform ${loaded ? "rotate-90" : ""}`} />
      </button>

      {loaded && (
        <div className="mt-2 rounded-2xl border border-white/8 overflow-hidden" style={{ background: "#0e0e16" }}>
          {busy ? (
            <div className="flex justify-center py-6">
              <div className="w-5 h-5 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
            </div>
          ) : sessions.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare size={28} className="mx-auto text-gray-700 mb-2" />
              <p className="text-xs text-gray-600">No history yet</p>
            </div>
          ) : (
            <div className="max-h-52 overflow-y-auto divide-y divide-white/5">
              {sessions.map(s => (
                <div key={s.date} className="px-4 py-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-semibold text-cyan-400">{s.date}</span>
                    <span className="text-[10px] text-gray-600">{s.count} msgs</span>
                  </div>
                  <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">{s.preview}</p>
                </div>
              ))}
            </div>
          )}
          <div className="p-2 border-t border-white/6">
            <button
              onClick={() => { onClearAll(); setSessions([]); setLoaded(false); }}
              className="flex items-center justify-center gap-2 w-full py-2 rounded-xl bg-red-500/8 hover:bg-red-500/16 text-red-400 text-xs font-medium transition-all border border-red-500/12"
            >
              <Trash2 size={12} /> Clear all history
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Profile sheet (left side, includes history) ──────── */
function ProfileSheet({ session, onClose, onSignOut, onClearChat }: {
  session: { user: { email?: string; created_at?: string } };
  onClose: () => void;
  onSignOut: () => void;
  onClearChat: () => void;
}) {
  const email     = session.user.email ?? "";
  const isPhone   = email.endsWith("@phone.jkbot.ai");
  const displayId = isPhone ? email.replace("@phone.jkbot.ai", "") : email;
  const label     = isPhone ? "Phone" : "Email";
  const initials  = displayId.slice(0, 2).toUpperCase();
  const joined    = session.user.created_at
    ? new Date(session.user.created_at).toLocaleDateString("en-IN", {
        day: "numeric", month: "long", year: "numeric",
      })
    : null;

  return (
    <div className="fixed inset-0 z-50 flex" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />

      {/* Slide-in panel from the LEFT (profile is now top-left) */}
      <div
        className="relative w-80 max-w-full h-full flex flex-col shadow-2xl animate-slide-in-right overflow-hidden"
        style={{ background: "#0e0e16", borderRight: "1px solid rgba(255,255,255,0.08)" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Neon accent stripe */}
        <div className="h-0.5 w-full flex-shrink-0"
          style={{ background: "linear-gradient(90deg, #06b6d4, #3b82f6, #8b5cf6)" }}
        />

        {/* Header row */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 flex-shrink-0">
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "#00d4ff" }}>
            My Profile
          </span>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full flex items-center justify-center transition-colors hover:bg-white/8"
            style={{ background: "rgba(255,255,255,0.05)" }}
          >
            <X size={13} className="text-gray-400" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">

          {/* Avatar card */}
          <div className="rounded-2xl border border-white/8 p-5 flex items-center gap-4"
            style={{ background: "rgba(255,255,255,0.03)" }}
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-lg font-bold flex-shrink-0"
              style={{
                background: "linear-gradient(135deg,#06b6d4,#3b82f6)",
                boxShadow: "0 0 20px rgba(6,182,212,0.3)",
              }}
            >
              {initials}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-white truncate">{displayId}</p>
              <p className="text-[11px] text-gray-500 mt-0.5">{label} account</p>
            </div>
          </div>

          {/* Account details */}
          <div className="rounded-2xl border border-white/8 p-4 space-y-3"
            style={{ background: "rgba(255,255,255,0.03)" }}
          >
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">Account type</span>
              <span className="text-gray-200 font-medium">Free</span>
            </div>
            {joined && (
              <div className="flex justify-between text-xs">
                <span className="text-gray-500">Member since</span>
                <span className="text-gray-200">{joined}</span>
              </div>
            )}
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">Status</span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" style={{ boxShadow: "0 0 6px #10b981" }} />
                Active
              </span>
            </div>
          </div>

          {/* Chat history — inline inside profile */}
          <HistoryList onClearAll={onClearChat} />

          {/* Sign out */}
          <button
            onClick={() => { onSignOut(); onClose(); }}
            className="flex items-center justify-between w-full px-4 py-3 rounded-2xl border text-sm transition-all"
            style={{
              background: "rgba(239,68,68,0.06)",
              borderColor: "rgba(239,68,68,0.15)",
              color: "#f87171",
            }}
          >
            <span className="flex items-center gap-2 font-medium">
              <LogOut size={15} />Sign out
            </span>
            <ChevronRight size={14} className="opacity-40" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Three-dot nav menu (now top-RIGHT) ───────────────── */
function NavMenu({
  activeTab, setActiveTab, session, onShowPricing, onSignOut, onClose,
}: {
  activeTab: Tab;
  setActiveTab: (t: Tab) => void;
  session: { user: { email?: string } } | null;
  onShowPricing: () => void;
  onSignOut: () => void;
  onClose: () => void;
}) {
  const navItems: { id: Tab; label: string; icon: typeof Bell }[] = [
    { id: "chat",      label: "Chat",      icon: MessageCircle },
    { id: "imagegen",  label: "Image Gen", icon: ImageIcon },
    { id: "reminders", label: "Reminders", icon: Bell },
    { id: "notes",     label: "Notes",     icon: BookOpen },
  ];

  function go(id: Tab) { setActiveTab(id); onClose(); }

  return (
    <div className="fixed inset-0 z-50 flex justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative mt-12 mr-3 w-60 self-start rounded-2xl border border-white/10 shadow-2xl shadow-black/70 overflow-hidden animate-fade-in"
        style={{ background: "#13131a" }}
        onClick={e => e.stopPropagation()}
      >
        <div className="h-0.5 w-full" style={{ background: "linear-gradient(90deg,#06b6d4,#3b82f6,#8b5cf6)" }} />

        <div className="p-2">
          <p className="text-[10px] uppercase tracking-widest text-gray-600 px-3 pt-2 pb-1.5 font-bold">Sections</p>
          {navItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => go(id)}
              className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium transition-all"
              style={activeTab === id
                ? { background: "rgba(0,212,255,0.1)", color: "#00d4ff", border: "1px solid rgba(0,212,255,0.2)" }
                : { color: "rgba(156,163,175,0.8)" }
              }
            >
              <Icon size={15} style={{ color: activeTab === id ? "#00d4ff" : "rgba(107,114,128,0.8)" }} />
              {label}
            </button>
          ))}

          <div className="my-2 border-t border-white/6" />
          <p className="text-[10px] uppercase tracking-widest text-gray-600 px-3 py-1.5 font-bold">Account</p>

          {session ? (
            <>
              <button
                onClick={() => { onShowPricing(); onClose(); }}
                className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm transition-all"
                style={{ color: "#fbbf24" }}
              >
                <Crown size={15} style={{ color: "#f59e0b" }} /> Upgrade to Pro
              </button>
              <button
                onClick={() => { onSignOut(); onClose(); }}
                className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm transition-all"
                style={{ color: "#f87171" }}
              >
                <LogOut size={15} style={{ color: "#ef4444" }} /> Sign out
              </button>
            </>
          ) : (
            <button
              onClick={onClose}
              className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm transition-all"
              style={{ color: "rgba(156,163,175,0.8)" }}
            >
              <Lock size={15} style={{ color: "rgba(107,114,128,0.8)" }} /> Login / Sign up
            </button>
          )}

          <div className="my-2 border-t border-white/6" />
          <button
            onClick={onClose}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm transition-all"
            style={{ color: "rgba(156,163,175,0.8)" }}
          >
            <Settings size={15} style={{ color: "rgba(107,114,128,0.8)" }} /> Settings
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Root App ──────────────────────────────────────────── */
export default function App() {
  const { session, loading, signIn, signUp, signOut } = useAuth();
  const subscription = useSubscription();
  const [activeTab,   setActiveTab]   = useState<Tab>("chat");
  const [showMenu,    setShowMenu]    = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [clearKey,    setClearKey]    = useState(0); // bump to reset ChatPanel

  function handleClearChat() {
    setClearKey(k => k + 1);
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#08080f" }}>
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center animate-pulse"
            style={{ background: "linear-gradient(135deg,#06b6d4,#3b82f6)", boxShadow: "0 0 24px rgba(6,182,212,0.3)" }}
          >
            <Sparkles size={24} className="text-white" />
          </div>
          <p className="text-sm text-gray-500">Loading JK Bot AI…</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen onSignIn={signIn} onSignUp={signUp} />;
  }

  const email     = session.user.email ?? "";
  const isPhone   = email.endsWith("@phone.jkbot.ai");
  const displayId = isPhone ? email.replace("@phone.jkbot.ai", "") : email;
  const initials  = displayId.slice(0, 2).toUpperCase();

  return (
    <div className="h-screen h-[100dvh] text-gray-100 flex flex-col" style={{ background: "#08080f" }}>

      {/* ── Header ── */}
      <header
        className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b"
        style={{ background: "#0e0e16", borderColor: "rgba(255,255,255,0.06)" }}
      >
        {/* LEFT: Profile avatar (moved from right) */}
        <button
          onClick={() => setShowProfile(v => !v)}
          className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold transition-all"
          style={{
            background: "linear-gradient(135deg,#06b6d4,#3b82f6)",
            boxShadow: "0 0 12px rgba(6,182,212,0.25)",
          }}
          title="Profile & History"
        >
          {initials}
        </button>

        {/* CENTER: brand */}
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg,#06b6d4,#3b82f6)",
              boxShadow: "0 0 10px rgba(6,182,212,0.2)",
            }}
          >
            <Sparkles size={14} className="text-white" />
          </div>
          <span
            className="text-sm font-bold tracking-tight"
            style={{ background: "linear-gradient(90deg,#67e8f9,#93c5fd)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
          >
            JK Bot AI
          </span>
        </div>

        {/* RIGHT: three-dot nav menu (moved from left) */}
        <button
          onClick={() => setShowMenu(v => !v)}
          className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-400 hover:text-white transition-all"
          style={{ background: "rgba(255,255,255,0.04)" }}
          title="Navigation"
        >
          <MoreVertical size={20} />
        </button>
      </header>

      {/* ── Content ── */}
      <div className="flex-1 overflow-hidden">
        {activeTab === "chat" ? (
          <ChatPanel key={clearKey} />
        ) : activeTab === "imagegen" ? (
          <ImageGenPanel onUpgrade={() => setShowPricing(true)} />
        ) : activeTab === "reminders" ? (
          <RemindersPanel />
        ) : (
          <NotesPanel />
        )}
      </div>

      {/* ── Overlays ── */}
      {showProfile && (
        <ProfileSheet
          session={session}
          onClose={() => setShowProfile(false)}
          onSignOut={signOut}
          onClearChat={handleClearChat}
        />
      )}

      {showMenu && (
        <NavMenu
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          session={session}
          onShowPricing={() => setShowPricing(true)}
          onSignOut={signOut}
          onClose={() => setShowMenu(false)}
        />
      )}

      {showPricing && (
        <PricingModal
          onClose={() => setShowPricing(false)}
          isPremium={subscription.isPremium}
          expiresAt={subscription.expiresAt}
        />
      )}
    </div>
  );
}
