import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const razorpayKeyId = Deno.env.get("RAZORPAY_KEY_ID");
const razorpayKeySecret = Deno.env.get("RAZORPAY_KEY_SECRET");

// Plan amounts in paise (1 INR = 100 paise)
// $5 ≈ ₹415, $10 ≈ ₹830 — using rounded INR amounts
const PLANS = {
  semi_annual: { amount: 41500, name: "JK Bot Premium — 6 Months", duration_months: 6, display_price: "₹415" },
  annual: { amount: 83000, name: "JK Bot Premium — 1 Year", duration_months: 12, display_price: "₹830" },
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action, plan, razorpay_payment_id, razorpay_order_id, razorpay_signature } = body;

    // === CREATE RAZORPAY ORDER ===
    if (action === "create_order") {
      if (!plan || !PLANS[plan as keyof typeof PLANS]) {
        return new Response(JSON.stringify({ error: "Invalid plan" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!razorpayKeyId || !razorpayKeySecret) {
        return new Response(JSON.stringify({
          demo_mode: true,
          message: "Razorpay is not yet configured. Contact the developer to set up payments.",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const planConfig = PLANS[plan as keyof typeof PLANS];

      // Create Razorpay order via REST API
      const orderRes = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          "Authorization": "Basic " + btoa(`${razorpayKeyId}:${razorpayKeySecret}`),
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: planConfig.amount,
          currency: "INR",
          receipt: `jkbot_${user.id.slice(0, 8)}_${Date.now()}`,
          notes: {
            user_id: user.id,
            plan: plan,
          },
        }),
      });

      if (!orderRes.ok) {
        const errText = await orderRes.text();
        console.error("Razorpay order error:", errText);
        return new Response(JSON.stringify({ error: "Payment setup failed" }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const order = await orderRes.json();

      return new Response(JSON.stringify({
        order_id: order.id,
        amount: order.amount,
        currency: order.currency,
        key_id: razorpayKeyId,
        plan_name: planConfig.name,
        display_price: planConfig.display_price,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // === VERIFY PAYMENT & ACTIVATE SUBSCRIPTION ===
    if (action === "verify_payment") {
      if (!razorpay_payment_id || !razorpay_order_id) {
        return new Response(JSON.stringify({ error: "Missing payment details" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!razorpayKeyId || !razorpayKeySecret) {
        return new Response(JSON.stringify({ error: "Razorpay not configured" }), {
          status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Verify the payment signature
      // Razorpay signature = HMAC-SHA256(order_id + "|" + payment_id, key_secret)
      if (razorpay_signature) {
        const crypto = globalThis.crypto.subtle;
        const encoder = new TextEncoder();
        const keyData = encoder.encode(razorpayKeySecret);
        const data = encoder.encode(`${razorpay_order_id}|${razorpay_payment_id}`);

        const key = await crypto.importKey(
          "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
        );
        const signature = await crypto.sign("HMAC", key, data);
        const expectedSig = btoa(String.fromCharCode(...new Uint8Array(signature)));

        if (expectedSig !== razorpay_signature) {
          return new Response(JSON.stringify({ error: "Invalid payment signature" }), {
            status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      }

      // Fetch the order to get plan info
      const orderRes = await fetch(`https://api.razorpay.com/v1/orders/${razorpay_order_id}`, {
        headers: {
          "Authorization": "Basic " + btoa(`${razorpayKeyId}:${razorpayKeySecret}`),
        },
      });

      if (!orderRes.ok) {
        return new Response(JSON.stringify({ error: "Failed to verify order" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const order = await orderRes.json();
      const plan = order.notes?.plan;
      if (!plan || !PLANS[plan as keyof typeof PLANS]) {
        return new Response(JSON.stringify({ error: "Invalid plan in order" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const planConfig = PLANS[plan as keyof typeof PLANS];
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + planConfig.duration_months);

      const serviceClient = createClient(supabaseUrl, supabaseServiceKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      });

      // Deactivate existing active subscription
      await serviceClient
        .from("subscriptions")
        .update({ status: "expired" })
        .eq("user_id", user.id)
        .eq("status", "active");

      // Insert new subscription
      const { error: insertError } = await serviceClient
        .from("subscriptions")
        .insert({
          user_id: user.id,
          plan,
          status: "active",
          razorpay_payment_id: razorpay_payment_id,
          started_at: new Date().toISOString(),
          expires_at: expiresAt.toISOString(),
        });

      if (insertError) {
        console.error("Insert subscription error:", insertError.message);
        return new Response(JSON.stringify({ error: "Failed to save subscription" }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({
        success: true,
        is_premium: true,
        plan,
        expires_at: expiresAt.toISOString(),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // === CHECK SUBSCRIPTION STATUS ===
    if (action === "check_status") {
      const serviceClient = createClient(supabaseUrl, supabaseServiceKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      });

      const { data: sub } = await serviceClient
        .from("subscriptions")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (sub && new Date(sub.expires_at) > new Date()) {
        return new Response(JSON.stringify({
          is_premium: true,
          plan: sub.plan,
          expires_at: sub.expires_at,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({
        is_premium: false,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Razorpay function error:", err);
    return new Response(
      JSON.stringify({
        error: err instanceof Error ? err.message : "Unknown error",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
